package com.service;

import java.util.List;
import java.util.Map;

import com.execption.PlayerNotFoundExecption;
import com.model.Player;

public interface PlayerService {

	public Player savePalyer(Player p);
	
	public Player getOnePlayer(int id);
	
	//public void deletePlayer(int id);
	
	public Map<String,Object>deletePlayer(int id)throws PlayerNotFoundExecption;
	
	public Player updatePlayer(Player p);
	
	public List<Player> getAllPlayer();
	
	
}
