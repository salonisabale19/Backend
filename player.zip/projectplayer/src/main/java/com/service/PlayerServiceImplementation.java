package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.PlayerRepository;
import com.execption.PlayerNotFoundExecption;
import com.model.Player;

@Service
public class PlayerServiceImplementation implements PlayerService  {

	@Autowired
	PlayerRepository playerRepo;

	@Override
	public Player savePalyer(Player p) {
		return playerRepo.save(p);
	}

	@Override
	public Player getOnePlayer(int id) {
		return playerRepo.findById(id).orElse(null);
	}

	
	public Map<String, Object> deletePlayer(int id) throws PlayerNotFoundExecption {
		Map<String,Object>response=new HashMap<String,Object>();
		try {
			Player player=playerRepo.findById(id).orElseThrow(()->new PlayerNotFoundExecption("player not found"));
			playerRepo.delete(player);
			response.put("Deleted", Boolean.TRUE);
		}
		catch(PlayerNotFoundExecption p)
		{
			response.put("deleted", p.getMessage());
		}
		return response;
	}

	@Override
	public Player updatePlayer(Player p) {
		Player player=playerRepo.findById(p.getPlayerId()).orElseThrow();
		player.setPlayerName(p.getPlayerName());
		return playerRepo.save(player);
	}

	@Override
	public List<Player> getAllPlayer() {
		return playerRepo.findAll();
	}

	
	
	

	/*@Override
	public void deletePlayer(int id) {
		playerRepo.deleteById(id);
	}*/

	
}
