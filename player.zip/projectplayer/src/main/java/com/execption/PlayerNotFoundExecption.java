package com.execption;

public class PlayerNotFoundExecption extends Exception {

	public PlayerNotFoundExecption(String s)
	{
		super(s);
	}
}
